CREATE TABLE `bookRecommendations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`memberId` int NOT NULL,
	`recommendedBookIds` json NOT NULL,
	`reasoning` text,
	`generatedAt` datetime NOT NULL,
	`expiryAt` datetime NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `bookRecommendations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `books` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`author` varchar(255) NOT NULL,
	`isbn` varchar(20),
	`genre` varchar(100),
	`description` text,
	`publicationDate` datetime,
	`totalCopies` int NOT NULL DEFAULT 1,
	`availableCopies` int NOT NULL DEFAULT 1,
	`publisher` varchar(255),
	`language` varchar(50) DEFAULT 'English',
	`pages` int,
	`coverImageUrl` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `books_id` PRIMARY KEY(`id`),
	CONSTRAINT `books_isbn_unique` UNIQUE(`isbn`)
);
--> statement-breakpoint
CREATE TABLE `fines` (
	`id` int AUTO_INCREMENT NOT NULL,
	`transactionId` int NOT NULL,
	`memberId` int NOT NULL,
	`amount` decimal(10,2) NOT NULL,
	`reason` varchar(255) NOT NULL,
	`status` enum('pending','paid','waived') NOT NULL DEFAULT 'pending',
	`paidDate` datetime,
	`waivedDate` datetime,
	`waivedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `fines_id` PRIMARY KEY(`id`),
	CONSTRAINT `fines_transactionId_unique` UNIQUE(`transactionId`)
);
--> statement-breakpoint
CREATE TABLE `librarySettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`settingKey` varchar(100) NOT NULL,
	`settingValue` text NOT NULL,
	`description` text,
	`dataType` varchar(50) DEFAULT 'string',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `librarySettings_id` PRIMARY KEY(`id`),
	CONSTRAINT `librarySettings_settingKey_unique` UNIQUE(`settingKey`)
);
--> statement-breakpoint
CREATE TABLE `memberProfiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`membershipNumber` varchar(50),
	`status` enum('active','inactive','suspended') NOT NULL DEFAULT 'active',
	`address` text,
	`city` varchar(100),
	`postalCode` varchar(20),
	`joinDate` datetime NOT NULL,
	`expiryDate` datetime,
	`totalBooksIssued` int DEFAULT 0,
	`totalFinesPaid` decimal(10,2) DEFAULT '0',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `memberProfiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `memberProfiles_userId_unique` UNIQUE(`userId`),
	CONSTRAINT `memberProfiles_membershipNumber_unique` UNIQUE(`membershipNumber`)
);
--> statement-breakpoint
CREATE TABLE `notificationPreferences` (
	`id` int AUTO_INCREMENT NOT NULL,
	`memberId` int NOT NULL,
	`overdueReminders` boolean DEFAULT true,
	`dueSoonAlerts` boolean DEFAULT true,
	`reservationNotifications` boolean DEFAULT true,
	`fineNotifications` boolean DEFAULT true,
	`emailNotifications` boolean DEFAULT false,
	`inAppNotifications` boolean DEFAULT true,
	`daysBefore` int DEFAULT 3,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `notificationPreferences_id` PRIMARY KEY(`id`),
	CONSTRAINT `notificationPreferences_memberId_unique` UNIQUE(`memberId`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`memberId` int NOT NULL,
	`type` enum('overdue_reminder','due_soon','reservation_ready','fine_pending','book_returned') NOT NULL,
	`title` varchar(255) NOT NULL,
	`message` text NOT NULL,
	`relatedBookId` int,
	`relatedTransactionId` int,
	`relatedReservationId` int,
	`isRead` boolean DEFAULT false,
	`deliveryChannels` varchar(100) DEFAULT 'in-app',
	`sentAt` datetime,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `reservations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookId` int NOT NULL,
	`memberId` int NOT NULL,
	`reservationDate` datetime NOT NULL,
	`status` enum('pending','ready','cancelled','expired') NOT NULL DEFAULT 'pending',
	`readyDate` datetime,
	`expiryDate` datetime,
	`notificationSent` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `reservations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookId` int NOT NULL,
	`memberId` int NOT NULL,
	`checkoutDate` datetime NOT NULL,
	`dueDate` datetime NOT NULL,
	`returnDate` datetime,
	`status` enum('active','returned','overdue') NOT NULL DEFAULT 'active',
	`renewalCount` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `transactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `phone` varchar(20);