import { 
  int, 
  mysqlEnum, 
  mysqlTable, 
  text, 
  timestamp, 
  varchar,
  decimal,
  boolean,
  datetime,
  json
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Supports both Librarian (admin) and Member (user) roles.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Books catalog table
 */
export const books = mysqlTable("books", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  author: varchar("author", { length: 255 }).notNull(),
  isbn: varchar("isbn", { length: 20 }).unique(),
  genre: varchar("genre", { length: 100 }),
  description: text("description"),
  publicationDate: datetime("publicationDate"),
  totalCopies: int("totalCopies").default(1).notNull(),
  availableCopies: int("availableCopies").default(1).notNull(),
  publisher: varchar("publisher", { length: 255 }),
  language: varchar("language", { length: 50 }).default("English"),
  pages: int("pages"),
  coverImageUrl: text("coverImageUrl"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Book = typeof books.$inferSelect;
export type InsertBook = typeof books.$inferInsert;

/**
 * Member profiles (extends users table for member-specific data)
 */
export const memberProfiles = mysqlTable("memberProfiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  membershipNumber: varchar("membershipNumber", { length: 50 }).unique(),
  status: mysqlEnum("status", ["active", "inactive", "suspended"]).default("active").notNull(),
  address: text("address"),
  city: varchar("city", { length: 100 }),
  postalCode: varchar("postalCode", { length: 20 }),
  joinDate: datetime("joinDate").notNull(),
  expiryDate: datetime("expiryDate"),
  totalBooksIssued: int("totalBooksIssued").default(0),
  totalFinesPaid: decimal("totalFinesPaid", { precision: 10, scale: 2 }).default("0"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MemberProfile = typeof memberProfiles.$inferSelect;
export type InsertMemberProfile = typeof memberProfiles.$inferInsert;

/**
 * Book transactions (checkouts and returns)
 */
export const transactions = mysqlTable("transactions", {
  id: int("id").autoincrement().primaryKey(),
  bookId: int("bookId").notNull(),
  memberId: int("memberId").notNull(),
  checkoutDate: datetime("checkoutDate").notNull(),
  dueDate: datetime("dueDate").notNull(),
  returnDate: datetime("returnDate"),
  status: mysqlEnum("status", ["active", "returned", "overdue"]).default("active").notNull(),
  renewalCount: int("renewalCount").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;

/**
 * Fine and penalty management
 */
export const fines = mysqlTable("fines", {
  id: int("id").autoincrement().primaryKey(),
  transactionId: int("transactionId").notNull().unique(),
  memberId: int("memberId").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  reason: varchar("reason", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["pending", "paid", "waived"]).default("pending").notNull(),
  paidDate: datetime("paidDate"),
  waivedDate: datetime("waivedDate"),
  waivedBy: int("waivedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Fine = typeof fines.$inferSelect;
export type InsertFine = typeof fines.$inferInsert;

/**
 * Book reservations
 */
export const reservations = mysqlTable("reservations", {
  id: int("id").autoincrement().primaryKey(),
  bookId: int("bookId").notNull(),
  memberId: int("memberId").notNull(),
  reservationDate: datetime("reservationDate").notNull(),
  status: mysqlEnum("status", ["pending", "ready", "cancelled", "expired"]).default("pending").notNull(),
  readyDate: datetime("readyDate"),
  expiryDate: datetime("expiryDate"),
  notificationSent: boolean("notificationSent").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Reservation = typeof reservations.$inferSelect;
export type InsertReservation = typeof reservations.$inferInsert;

/**
 * Notifications (in-app and email)
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  memberId: int("memberId").notNull(),
  type: mysqlEnum("type", [
    "overdue_reminder",
    "due_soon",
    "reservation_ready",
    "fine_pending",
    "book_returned"
  ]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  relatedBookId: int("relatedBookId"),
  relatedTransactionId: int("relatedTransactionId"),
  relatedReservationId: int("relatedReservationId"),
  isRead: boolean("isRead").default(false),
  deliveryChannels: varchar("deliveryChannels", { length: 100 }).default("in-app"),
  sentAt: datetime("sentAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * Library settings (configurable rates and preferences)
 */
export const librarySettings = mysqlTable("librarySettings", {
  id: int("id").autoincrement().primaryKey(),
  settingKey: varchar("settingKey", { length: 100 }).notNull().unique(),
  settingValue: text("settingValue").notNull(),
  description: text("description"),
  dataType: varchar("dataType", { length: 50 }).default("string"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type LibrarySetting = typeof librarySettings.$inferSelect;
export type InsertLibrarySetting = typeof librarySettings.$inferInsert;

/**
 * Member notification preferences
 */
export const notificationPreferences = mysqlTable("notificationPreferences", {
  id: int("id").autoincrement().primaryKey(),
  memberId: int("memberId").notNull().unique(),
  overdueReminders: boolean("overdueReminders").default(true),
  dueSoonAlerts: boolean("dueSoonAlerts").default(true),
  reservationNotifications: boolean("reservationNotifications").default(true),
  fineNotifications: boolean("fineNotifications").default(true),
  emailNotifications: boolean("emailNotifications").default(false),
  inAppNotifications: boolean("inAppNotifications").default(true),
  daysBefore: int("daysBefore").default(3),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type NotificationPreference = typeof notificationPreferences.$inferSelect;
export type InsertNotificationPreference = typeof notificationPreferences.$inferInsert;

/**
 * Book recommendations cache (from LLM)
 */
export const bookRecommendations = mysqlTable("bookRecommendations", {
  id: int("id").autoincrement().primaryKey(),
  memberId: int("memberId").notNull(),
  recommendedBookIds: json("recommendedBookIds").$type<number[]>().notNull(),
  reasoning: text("reasoning"),
  generatedAt: datetime("generatedAt").notNull(),
  expiryAt: datetime("expiryAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BookRecommendation = typeof bookRecommendations.$inferSelect;
export type InsertBookRecommendation = typeof bookRecommendations.$inferInsert;
