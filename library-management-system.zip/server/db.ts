import { eq, and, or, like, gte, lte, desc, asc, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users,
  books,
  memberProfiles,
  transactions,
  fines,
  reservations,
  notifications,
  notificationPreferences,
  librarySettings,
  bookRecommendations,
  Book,
  MemberProfile,
  Transaction,
  Fine,
  Reservation,
  Notification,
  LibrarySetting
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod", "phone"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============ BOOK QUERIES ============

export async function createBook(book: typeof books.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(books).values(book);
  return result;
}

export async function updateBook(id: number, updates: Partial<typeof books.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(books).set(updates).where(eq(books.id, id));
}

export async function deleteBook(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(books).where(eq(books.id, id));
}

export async function getBookById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(books).where(eq(books.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllBooks(limit: number = 100, offset: number = 0) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(books).limit(limit).offset(offset);
}

export async function searchBooks(query: string, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(books)
    .where(
      or(
        like(books.title, `%${query}%`),
        like(books.author, `%${query}%`),
        like(books.isbn, `%${query}%`),
        like(books.genre, `%${query}%`)
      )
    )
    .limit(limit);
}

export async function filterBooks(filters: {
  genre?: string;
  availability?: "available" | "unavailable";
  author?: string;
}) {
  const db = await getDb();
  if (!db) return [];
  
  const conditions = [];
  if (filters.genre) conditions.push(eq(books.genre, filters.genre));
  if (filters.availability === "available") conditions.push(sql`${books.availableCopies} > 0`);
  if (filters.availability === "unavailable") conditions.push(sql`${books.availableCopies} = 0`);
  if (filters.author) conditions.push(like(books.author, `%${filters.author}%`));

  return await db.select().from(books)
    .where(conditions.length > 0 ? and(...conditions) : undefined);
}

// ============ MEMBER QUERIES ============

export async function createMemberProfile(profile: typeof memberProfiles.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(memberProfiles).values(profile);
  return result;
}

export async function getMemberProfile(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(memberProfiles).where(eq(memberProfiles.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateMemberProfile(userId: number, updates: Partial<typeof memberProfiles.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(memberProfiles).set(updates).where(eq(memberProfiles.userId, userId));
}

export async function getAllMembers(limit: number = 100, offset: number = 0) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(memberProfiles).limit(limit).offset(offset);
}

export async function searchMembers(query: string) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select({
    profile: memberProfiles,
    user: users
  })
  .from(memberProfiles)
  .innerJoin(users, eq(memberProfiles.userId, users.id))
  .where(
    or(
      like(users.name, `%${query}%`),
      like(users.email, `%${query}%`),
      like(memberProfiles.membershipNumber, `%${query}%`)
    )
  );
}

// ============ TRANSACTION QUERIES ============

export async function createTransaction(transaction: typeof transactions.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(transactions).values(transaction);
  return result;
}

export async function getTransactionById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(transactions).where(eq(transactions.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateTransaction(id: number, updates: Partial<typeof transactions.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(transactions).set(updates).where(eq(transactions.id, id));
}

export async function getMemberTransactions(memberId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(transactions)
    .where(eq(transactions.memberId, memberId))
    .orderBy(desc(transactions.checkoutDate));
}

export async function getActiveTransactions(memberId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(transactions)
    .where(and(eq(transactions.memberId, memberId), eq(transactions.status, "active")));
}

export async function getOverdueTransactions() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(transactions)
    .where(and(
      eq(transactions.status, "active"),
      lte(transactions.dueDate, new Date())
    ));
}

// ============ FINE QUERIES ============

export async function createFine(fine: typeof fines.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(fines).values(fine);
  return result;
}

export async function getFineByTransactionId(transactionId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(fines).where(eq(fines.transactionId, transactionId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getMemberFines(memberId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(fines)
    .where(eq(fines.memberId, memberId))
    .orderBy(desc(fines.createdAt));
}

export async function getPendingFines(memberId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(fines)
    .where(and(eq(fines.memberId, memberId), eq(fines.status, "pending")));
}

export async function updateFine(id: number, updates: Partial<typeof fines.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(fines).set(updates).where(eq(fines.id, id));
}

// ============ RESERVATION QUERIES ============

export async function createReservation(reservation: typeof reservations.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(reservations).values(reservation);
  return result;
}

export async function getReservationById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(reservations).where(eq(reservations.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getBookReservations(bookId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(reservations)
    .where(and(eq(reservations.bookId, bookId), eq(reservations.status, "pending")))
    .orderBy(asc(reservations.reservationDate));
}

export async function getMemberReservations(memberId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(reservations)
    .where(eq(reservations.memberId, memberId))
    .orderBy(desc(reservations.reservationDate));
}

export async function updateReservation(id: number, updates: Partial<typeof reservations.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(reservations).set(updates).where(eq(reservations.id, id));
}

// ============ NOTIFICATION QUERIES ============

export async function createNotification(notification: typeof notifications.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(notifications).values(notification);
  return result;
}

export async function getMemberNotifications(memberId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(notifications)
    .where(eq(notifications.memberId, memberId))
    .orderBy(desc(notifications.createdAt))
    .limit(limit);
}

export async function getUnreadNotifications(memberId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(notifications)
    .where(and(eq(notifications.memberId, memberId), eq(notifications.isRead, false)))
    .orderBy(desc(notifications.createdAt));
}

export async function updateNotification(id: number, updates: Partial<typeof notifications.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(notifications).set(updates).where(eq(notifications.id, id));
}

// ============ NOTIFICATION PREFERENCES QUERIES ============

export async function getNotificationPreferences(memberId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(notificationPreferences)
    .where(eq(notificationPreferences.memberId, memberId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createNotificationPreferences(prefs: typeof notificationPreferences.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(notificationPreferences).values(prefs);
  return result;
}

export async function updateNotificationPreferences(memberId: number, updates: Partial<typeof notificationPreferences.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(notificationPreferences).set(updates).where(eq(notificationPreferences.memberId, memberId));
}

// ============ LIBRARY SETTINGS QUERIES ============

export async function getLibrarySetting(key: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(librarySettings)
    .where(eq(librarySettings.settingKey, key)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function setLibrarySetting(key: string, value: string, description?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const existing = await getLibrarySetting(key);
  if (existing) {
    await db.update(librarySettings).set({ settingValue: value }).where(eq(librarySettings.settingKey, key));
  } else {
    await db.insert(librarySettings).values({ settingKey: key, settingValue: value, description });
  }
}

export async function getAllSettings() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(librarySettings);
}

// ============ BOOK RECOMMENDATIONS QUERIES ============

export async function getBookRecommendations(memberId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(bookRecommendations)
    .where(eq(bookRecommendations.memberId, memberId))
    .orderBy(desc(bookRecommendations.generatedAt))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createBookRecommendations(rec: typeof bookRecommendations.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(bookRecommendations).values(rec);
  return result;
}

// ============ ANALYTICS QUERIES ============

export async function getBorrowingTrends(days: number = 30) {
  const db = await getDb();
  if (!db) return [];
  
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days);
  
  return await db.select({
    date: sql`DATE(${transactions.checkoutDate})`,
    count: sql`COUNT(*)`
  })
  .from(transactions)
  .where(gte(transactions.checkoutDate, startDate))
  .groupBy(sql`DATE(${transactions.checkoutDate})`)
  .orderBy(asc(sql`DATE(${transactions.checkoutDate})`));
}

export async function getMostPopularBooks(limit: number = 10) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select({
    book: books,
    borrowCount: sql`COUNT(${transactions.id})`
  })
  .from(books)
  .leftJoin(transactions, eq(books.id, transactions.bookId))
  .groupBy(books.id)
  .orderBy(desc(sql`COUNT(${transactions.id})`))
  .limit(limit);
}

export async function getActiveMembers() {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select({
    profile: memberProfiles,
    activeTransactions: sql`COUNT(${transactions.id})`
  })
  .from(memberProfiles)
  .leftJoin(transactions, and(
    eq(memberProfiles.userId, transactions.memberId),
    eq(transactions.status, "active")
  ))
  .groupBy(memberProfiles.id)
  .orderBy(desc(sql`COUNT(${transactions.id})`));
}

export async function getOverdueStats() {
  const db = await getDb();
  if (!db) return { count: 0, totalFines: 0 };
  
  const overdueCount = await db.select({ count: sql`COUNT(*)` })
    .from(transactions)
    .where(and(
      eq(transactions.status, "active"),
      lte(transactions.dueDate, new Date())
    ));
  
  const totalFines = await db.select({ total: sql`SUM(${fines.amount})` })
    .from(fines)
    .where(eq(fines.status, "pending"));
  
  return {
    overdueCount: overdueCount[0]?.count || 0,
    totalPendingFines: totalFines[0]?.total || 0
  };
}
