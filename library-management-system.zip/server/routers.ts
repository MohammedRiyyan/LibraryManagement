import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import * as db from "./db";
import { invokeLLM } from "./_core/llm";

// Helper to check if user is librarian
const librarianProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Only librarians can access this" });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ============ BOOKS ROUTES ============
  books: router({
    list: publicProcedure
      .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
      .query(async ({ input }) => {
        return await db.getAllBooks(input.limit, input.offset);
      }),

    search: publicProcedure
      .input(z.object({ query: z.string().min(1), limit: z.number().default(50) }))
      .query(async ({ input }) => {
        return await db.searchBooks(input.query, input.limit);
      }),

    filter: publicProcedure
      .input(z.object({
        genre: z.string().optional(),
        availability: z.enum(["available", "unavailable"]).optional(),
        author: z.string().optional(),
      }))
      .query(async ({ input }) => {
        return await db.filterBooks(input);
      }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getBookById(input.id);
      }),

    create: librarianProcedure
      .input(z.object({
        title: z.string().min(1),
        author: z.string().min(1),
        isbn: z.string().optional(),
        genre: z.string().optional(),
        description: z.string().optional(),
        publicationDate: z.date().optional(),
        totalCopies: z.number().default(1),
        publisher: z.string().optional(),
        language: z.string().default("English"),
        pages: z.number().optional(),
        coverImageUrl: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.createBook({
          ...input,
          availableCopies: input.totalCopies,
        });
        return { success: true };
      }),

    update: librarianProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        author: z.string().optional(),
        genre: z.string().optional(),
        description: z.string().optional(),
        totalCopies: z.number().optional(),
        availableCopies: z.number().optional(),
        publisher: z.string().optional(),
        pages: z.number().optional(),
        coverImageUrl: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...updates } = input;
        await db.updateBook(id, updates);
        return { success: true };
      }),

    delete: librarianProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteBook(input.id);
        return { success: true };
      }),
  }),

  // ============ MEMBERS ROUTES ============
  members: router({
    list: librarianProcedure
      .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
      .query(async ({ input }) => {
        return await db.getAllMembers(input.limit, input.offset);
      }),

    search: librarianProcedure
      .input(z.object({ query: z.string().min(1) }))
      .query(async ({ input }) => {
        return await db.searchMembers(input.query);
      }),

    getProfile: protectedProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ input, ctx }) => {
        // Members can only see their own profile, librarians can see all
        if (ctx.user.role !== "admin" && ctx.user.id !== input.userId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.getMemberProfile(input.userId);
      }),

    register: librarianProcedure
      .input(z.object({
        userId: z.number(),
        membershipNumber: z.string(),
        address: z.string().optional(),
        city: z.string().optional(),
        postalCode: z.string().optional(),
        expiryDate: z.date().optional(),
      }))
      .mutation(async ({ input }) => {
        const existing = await db.getMemberProfile(input.userId);
        if (existing) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Member already registered" });
        }
        
        await db.createMemberProfile({
          userId: input.userId,
          membershipNumber: input.membershipNumber,
          address: input.address,
          city: input.city,
          postalCode: input.postalCode,
          joinDate: new Date(),
          expiryDate: input.expiryDate,
          status: "active",
        });

        // Create default notification preferences
        await db.createNotificationPreferences({
          memberId: input.userId,
          overdueReminders: true,
          dueSoonAlerts: true,
          reservationNotifications: true,
          fineNotifications: true,
          emailNotifications: false,
          inAppNotifications: true,
          daysBefore: 3,
        });

        return { success: true };
      }),

    updateProfile: protectedProcedure
      .input(z.object({
        userId: z.number(),
        address: z.string().optional(),
        city: z.string().optional(),
        postalCode: z.string().optional(),
        status: z.enum(["active", "inactive", "suspended"]).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        // Members can only update their own profile
        if (ctx.user.role !== "admin" && ctx.user.id !== input.userId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        const updates: any = {};
        if (input.address !== undefined) updates.address = input.address;
        if (input.city !== undefined) updates.city = input.city;
        if (input.postalCode !== undefined) updates.postalCode = input.postalCode;
        if (input.status !== undefined && ctx.user.role === "admin") updates.status = input.status;

        await db.updateMemberProfile(input.userId, updates);
        return { success: true };
      }),
  }),

  // ============ TRANSACTIONS ROUTES ============
  transactions: router({
    checkout: librarianProcedure
      .input(z.object({
        bookId: z.number(),
        memberId: z.number(),
        daysToReturn: z.number().default(14),
      }))
      .mutation(async ({ input }) => {
        const book = await db.getBookById(input.bookId);
        if (!book || book.availableCopies <= 0) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Book not available" });
        }

        const member = await db.getMemberProfile(input.memberId);
        if (!member || member.status !== "active") {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Member not active" });
        }

        const checkoutDate = new Date();
        const dueDate = new Date();
        dueDate.setDate(dueDate.getDate() + input.daysToReturn);

        await db.createTransaction({
          bookId: input.bookId,
          memberId: input.memberId,
          checkoutDate,
          dueDate,
          status: "active",
        });

        // Decrease available copies
        await db.updateBook(input.bookId, {
          availableCopies: book.availableCopies - 1,
        });

        // Update member stats
        await db.updateMemberProfile(input.memberId, {
          totalBooksIssued: (member.totalBooksIssued || 0) + 1,
        });

        return { success: true };
      }),

    return: librarianProcedure
      .input(z.object({
        transactionId: z.number(),
      }))
      .mutation(async ({ input }) => {
        const transaction = await db.getTransactionById(input.transactionId);
        if (!transaction) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }

        const book = await db.getBookById(transaction.bookId);
        if (!book) throw new TRPCError({ code: "NOT_FOUND" });

        const returnDate = new Date();
        const isOverdue = returnDate > transaction.dueDate;

        // Update transaction
        await db.updateTransaction(input.transactionId, {
          returnDate,
          status: "returned",
        });

        // Increase available copies
        await db.updateBook(transaction.bookId, {
          availableCopies: book.availableCopies + 1,
        });

        // Calculate and create fine if overdue
        if (isOverdue) {
          const fineRateSetting = await db.getLibrarySetting("daily_fine_rate");
          const dailyRate = parseFloat(fineRateSetting?.settingValue || "5");
          
          const daysOverdue = Math.ceil(
            (returnDate.getTime() - transaction.dueDate.getTime()) / (1000 * 60 * 60 * 24)
          );
          const fineAmount = daysOverdue * dailyRate;

          await db.createFine({
            transactionId: input.transactionId,
            memberId: transaction.memberId,
            amount: fineAmount.toString(),
            reason: `Overdue by ${daysOverdue} days`,
            status: "pending",
          });

          // Create notification
          await db.createNotification({
            memberId: transaction.memberId,
            type: "overdue_reminder",
            title: "Book Overdue - Fine Generated",
            message: `Your book "${book.title}" was overdue by ${daysOverdue} days. A fine of $${fineAmount.toFixed(2)} has been generated.`,
            relatedBookId: transaction.bookId,
            relatedTransactionId: input.transactionId,
          });
        }

        // Check for reservations
        const reservations = await db.getBookReservations(transaction.bookId);
        if (reservations.length > 0) {
          const nextReservation = reservations[0];
          await db.updateReservation(nextReservation.id, {
            status: "ready",
            readyDate: new Date(),
            notificationSent: false,
          });

          // Create notification for reserved member
          await db.createNotification({
            memberId: nextReservation.memberId,
            type: "reservation_ready",
            title: "Reserved Book Available",
            message: `The book "${book.title}" you reserved is now available for pickup.`,
            relatedBookId: transaction.bookId,
            relatedReservationId: nextReservation.id,
          });
        }

        return { success: true };
      }),

    getMemberHistory: protectedProcedure
      .input(z.object({ memberId: z.number() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.id !== input.memberId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.getMemberTransactions(input.memberId);
      }),

    getActive: protectedProcedure
      .input(z.object({ memberId: z.number() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.id !== input.memberId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.getActiveTransactions(input.memberId);
      }),

    getOverdue: librarianProcedure
      .query(async () => {
        return await db.getOverdueTransactions();
      }),
  }),

  // ============ FINES ROUTES ============
  fines: router({
    getMemberFines: protectedProcedure
      .input(z.object({ memberId: z.number() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.id !== input.memberId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.getMemberFines(input.memberId);
      }),

    getPending: protectedProcedure
      .input(z.object({ memberId: z.number() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.id !== input.memberId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.getPendingFines(input.memberId);
      }),

    payFine: protectedProcedure
      .input(z.object({ fineId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const fine = await db.getFineByTransactionId(input.fineId);
        if (!fine) throw new TRPCError({ code: "NOT_FOUND" });

        if (ctx.user.role !== "admin" && ctx.user.id !== fine.memberId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        await db.updateFine(input.fineId, {
          status: "paid",
          paidDate: new Date(),
        });

        // Update member total fines paid
        const member = await db.getMemberProfile(fine.memberId);
        if (member) {
          const currentTotal = parseFloat(member.totalFinesPaid?.toString() || "0");
          const fineAmount = parseFloat(fine.amount?.toString() || "0");
          await db.updateMemberProfile(fine.memberId, {
            totalFinesPaid: (currentTotal + fineAmount).toString(),
          });
        }

        return { success: true };
      }),

    waiveFine: librarianProcedure
      .input(z.object({ fineId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        await db.updateFine(input.fineId, {
          status: "waived",
          waivedDate: new Date(),
          waivedBy: ctx.user.id,
        });
        return { success: true };
      }),
  }),

  // ============ RESERVATIONS ROUTES ============
  reservations: router({
    create: protectedProcedure
      .input(z.object({ bookId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const book = await db.getBookById(input.bookId);
        if (!book) throw new TRPCError({ code: "NOT_FOUND" });

        // Check if book is available
        if (book.availableCopies > 0) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Book is available, no need to reserve" });
        }

        // Check if already reserved
        const existing = await db.getMemberReservations(ctx.user.id);
        if (existing.some(r => r.bookId === input.bookId && r.status === "pending")) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Already reserved this book" });
        }

        const expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + 30);

        await db.createReservation({
          bookId: input.bookId,
          memberId: ctx.user.id,
          reservationDate: new Date(),
          status: "pending",
          expiryDate,
        });

        return { success: true };
      }),

    getMemberReservations: protectedProcedure
      .query(async ({ ctx }) => {
        return await db.getMemberReservations(ctx.user.id);
      }),

    cancel: protectedProcedure
      .input(z.object({ reservationId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const reservation = await db.getReservationById(input.reservationId);
        if (!reservation) throw new TRPCError({ code: "NOT_FOUND" });

        if (ctx.user.role !== "admin" && ctx.user.id !== reservation.memberId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        await db.updateReservation(input.reservationId, { status: "cancelled" });
        return { success: true };
      }),

    getBookQueue: librarianProcedure
      .input(z.object({ bookId: z.number() }))
      .query(async ({ input }) => {
        return await db.getBookReservations(input.bookId);
      }),
  }),

  // ============ NOTIFICATIONS ROUTES ============
  notifications: router({
    list: protectedProcedure
      .input(z.object({ limit: z.number().default(50) }))
      .query(async ({ input, ctx }) => {
        return await db.getMemberNotifications(ctx.user.id, input.limit);
      }),

    getUnread: protectedProcedure
      .query(async ({ ctx }) => {
        return await db.getUnreadNotifications(ctx.user.id);
      }),

    markAsRead: protectedProcedure
      .input(z.object({ notificationId: z.number() }))
      .mutation(async ({ input }) => {
        await db.updateNotification(input.notificationId, { isRead: true });
        return { success: true };
      }),

    getPreferences: protectedProcedure
      .query(async ({ ctx }) => {
        return await db.getNotificationPreferences(ctx.user.id);
      }),

    updatePreferences: protectedProcedure
      .input(z.object({
        overdueReminders: z.boolean().optional(),
        dueSoonAlerts: z.boolean().optional(),
        reservationNotifications: z.boolean().optional(),
        fineNotifications: z.boolean().optional(),
        emailNotifications: z.boolean().optional(),
        inAppNotifications: z.boolean().optional(),
        daysBefore: z.number().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        await db.updateNotificationPreferences(ctx.user.id, input);
        return { success: true };
      }),
  }),

  // ============ SETTINGS ROUTES ============
  settings: router({
    getAll: librarianProcedure
      .query(async () => {
        return await db.getAllSettings();
      }),

    get: librarianProcedure
      .input(z.object({ key: z.string() }))
      .query(async ({ input }) => {
        return await db.getLibrarySetting(input.key);
      }),

    set: librarianProcedure
      .input(z.object({
        key: z.string(),
        value: z.string(),
        description: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.setLibrarySetting(input.key, input.value, input.description);
        return { success: true };
      }),
  }),

  // ============ ANALYTICS ROUTES ============
  analytics: router({
    borrowingTrends: librarianProcedure
      .input(z.object({ days: z.number().default(30) }))
      .query(async ({ input }) => {
        return await db.getBorrowingTrends(input.days);
      }),

    mostPopularBooks: librarianProcedure
      .input(z.object({ limit: z.number().default(10) }))
      .query(async ({ input }) => {
        return await db.getMostPopularBooks(input.limit);
      }),

    activeMembers: librarianProcedure
      .query(async () => {
        return await db.getActiveMembers();
      }),

    overdueStats: librarianProcedure
      .query(async () => {
        return await db.getOverdueStats();
      }),
  }),

  // ============ RECOMMENDATIONS ROUTES ============
  recommendations: router({
    generate: protectedProcedure
      .query(async ({ ctx }) => {
        // Check if recent recommendations exist
        const existing = await db.getBookRecommendations(ctx.user.id);
        if (existing && existing.expiryAt > new Date()) {
          return existing;
        }

        // Get member's borrowing history
        const transactions = await db.getMemberTransactions(ctx.user.id);
        if (transactions.length === 0) {
          return null;
        }

        // Get book details for borrowed books
        const borrowedBooks = await Promise.all(
          transactions.slice(0, 10).map(t => db.getBookById(t.bookId))
        );

        const bookTitles = borrowedBooks.filter(b => b).map(b => b!.title).join(", ");

        // Call LLM for recommendations
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: "You are a library recommendation system. Based on the member's borrowing history, recommend 5 books they might enjoy. Return a JSON object with 'recommendations' array containing book titles and 'reasoning' string."
            },
            {
              role: "user",
              content: `Member has borrowed: ${bookTitles}. Please recommend 5 books they might enjoy.`
            }
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "recommendations",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  recommendations: {
                    type: "array",
                    items: { type: "string" },
                    description: "List of recommended book titles"
                  },
                  reasoning: {
                    type: "string",
                    description: "Why these books were recommended"
                  }
                },
                required: ["recommendations", "reasoning"],
                additionalProperties: false
              }
            }
          }
        });

        // Parse response and search for book IDs
        const content = response.choices[0]?.message.content;
        if (!content) return null;

        const contentStr = typeof content === 'string' ? content : JSON.stringify(content);
        const parsed = JSON.parse(contentStr);
        const recommendedTitles = parsed.recommendations || [];

        // Search for matching books
        const recommendedBooks = [];
        for (const title of recommendedTitles) {
          const results = await db.searchBooks(title, 1);
          if (results.length > 0) {
            recommendedBooks.push(results[0].id);
          }
        }

        // Save recommendations
        const expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + 7);

        await db.createBookRecommendations({
          memberId: ctx.user.id,
          recommendedBookIds: recommendedBooks,
          reasoning: parsed.reasoning,
          generatedAt: new Date(),
          expiryAt: expiryDate,
        });

        return {
          memberId: ctx.user.id,
          recommendedBookIds: recommendedBooks,
          reasoning: parsed.reasoning,
          generatedAt: new Date(),
          expiryAt: expiryDate,
        };
      }),

    get: protectedProcedure
      .query(async ({ ctx }) => {
        return await db.getBookRecommendations(ctx.user.id);
      }),
  }),
});

export type AppRouter = typeof appRouter;
