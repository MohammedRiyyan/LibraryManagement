import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, BookOpen, Heart, Clock, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";

export default function MemberDashboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("discover");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGenre, setSelectedGenre] = useState<string | undefined>();

  // Fetch member profile
  const { data: memberProfile } = trpc.members.getProfile.useQuery(
    { userId: user?.id || 0 },
    { enabled: !!user?.id }
  );

  // Fetch books
  const { data: books = [], isLoading: booksLoading } = trpc.books.list.useQuery({ limit: 100 });
  const { data: searchResults = [] } = trpc.books.search.useQuery(
    { query: searchQuery, limit: 50 },
    { enabled: searchQuery.length > 0 }
  );

  // Fetch member data
  const { data: activeTransactions = [] } = trpc.transactions.getActive.useQuery(
    { memberId: user?.id || 0 },
    { enabled: !!user?.id }
  );

  const { data: memberFines = [] } = trpc.fines.getPending.useQuery(
    { memberId: user?.id || 0 },
    { enabled: !!user?.id }
  );

  const { data: memberReservations = [] } = trpc.reservations.getMemberReservations.useQuery(
    undefined,
    { enabled: !!user?.id }
  );

  const { data: recommendations } = trpc.recommendations.get.useQuery(
    undefined,
    { enabled: !!user?.id }
  );

  // Mutations
  const reserveBookMutation = trpc.reservations.create.useMutation({
    onSuccess: () => {
      toast.success("Book reserved successfully");
    },
    onError: (error) => {
      toast.error(error.message || "Failed to reserve book");
    },
  });

  const handleReserveBook = (bookId: number) => {
    reserveBookMutation.mutate({ bookId });
  };

  const displayBooks = searchQuery ? searchResults : books;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="card-cinematic p-8">
        <h1 className="heading-cinematic text-3xl md:text-4xl">Welcome, {user?.name}</h1>
        <p className="subheading-cinematic mt-2">Discover and manage your library experience</p>
      </div>

      {/* Quick Stats */}
      <div className="grid-cinematic">
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="stat-label">Active Loans</p>
              <p className="stat-value">{activeTransactions.length}</p>
            </div>
            <BookOpen className="w-12 h-12 text-primary opacity-50" />
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="stat-label">Pending Fines</p>
              <p className="stat-value">${memberFines.reduce((sum, f) => sum + parseFloat(f.amount?.toString() || "0"), 0).toFixed(2)}</p>
            </div>
            <AlertCircle className="w-12 h-12 text-secondary opacity-50" />
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="stat-label">Reservations</p>
              <p className="stat-value">{memberReservations.length}</p>
            </div>
            <Heart className="w-12 h-12 text-primary opacity-50" />
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="stat-label">Member Since</p>
              <p className="stat-value text-lg">
                {memberProfile?.joinDate
                  ? new Date(memberProfile.joinDate).toLocaleDateString()
                  : "N/A"}
              </p>
            </div>
            <Clock className="w-12 h-12 text-primary opacity-50" />
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="card-cinematic p-6">
        <TabsList className="grid w-full grid-cols-4 bg-card/50">
          <TabsTrigger value="discover">Discover</TabsTrigger>
          <TabsTrigger value="active">My Loans</TabsTrigger>
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
          <TabsTrigger value="account">Account</TabsTrigger>
        </TabsList>

        {/* Discover Tab */}
        <TabsContent value="discover" className="space-y-4 mt-6">
          <div className="flex gap-2 mb-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search books by title, author, or ISBN..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="input-cinematic pl-10"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {booksLoading ? (
              <div className="col-span-full text-center py-8 text-muted-foreground">Loading books...</div>
            ) : displayBooks.length === 0 ? (
              <div className="col-span-full text-center py-8 text-muted-foreground">No books found</div>
            ) : (
              displayBooks.map((book) => (
                <Card key={book.id} className="card-cinematic p-4 flex flex-col">
                  <div className="flex-1">
                    <h3 className="font-semibold text-foreground truncate-2">{book.title}</h3>
                    <p className="text-sm text-muted-foreground truncate">{book.author}</p>
                    {book.genre && <p className="text-xs text-primary mt-2">{book.genre}</p>}
                    <p className="text-xs text-muted-foreground mt-2">{book.description?.substring(0, 80)}...</p>
                  </div>

                  <div className="mt-4 pt-4 border-t border-border">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-sm font-medium text-foreground">
                        {book.availableCopies > 0 ? (
                          <span className="text-primary">Available: {book.availableCopies}</span>
                        ) : (
                          <span className="text-secondary">Unavailable</span>
                        )}
                      </span>
                    </div>
                    <Button
                      disabled={book.availableCopies === 0}
                      onClick={() => handleReserveBook(book.id)}
                      className="w-full btn-cinematic text-sm"
                    >
                      {book.availableCopies > 0 ? "Reserve" : "Reserve (Waitlist)"}
                    </Button>
                  </div>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        {/* Active Loans Tab */}
        <TabsContent value="active" className="space-y-4 mt-6">
          {activeTransactions.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <BookOpen className="w-12 h-12 mx-auto opacity-50 mb-2" />
              <p>You have no active loans</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="table-cinematic">
                <thead>
                  <tr>
                    <th>Book ID</th>
                    <th>Checkout Date</th>
                    <th>Due Date</th>
                    <th>Days Left</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {activeTransactions.map((transaction: any) => {
                    const daysLeft = Math.ceil(
                      (new Date(transaction.dueDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
                    );
                    const isOverdue = daysLeft < 0;
                    return (
                      <tr key={transaction.id}>
                        <td className="font-medium">Book #{transaction.bookId}</td>
                        <td className="text-sm text-muted-foreground">
                          {new Date(transaction.checkoutDate).toLocaleDateString()}
                        </td>
                        <td className="text-sm text-muted-foreground">
                          {new Date(transaction.dueDate).toLocaleDateString()}
                        </td>
                        <td>
                          <span className={isOverdue ? "badge-cinematic-orange" : "badge-cinematic"}>
                            {isOverdue ? `${Math.abs(daysLeft)} days overdue` : `${daysLeft} days left`}
                          </span>
                        </td>
                        <td>
                          <span className="badge-cinematic">{transaction.status}</span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </TabsContent>

        {/* Recommendations Tab */}
        <TabsContent value="recommendations" className="space-y-4 mt-6">
          {!recommendations ? (
            <div className="text-center py-8 text-muted-foreground">
              <p>No recommendations available yet. Borrow more books to get personalized recommendations!</p>
            </div>
          ) : (
            <div>
              <p className="text-muted-foreground mb-4">{recommendations.reasoning}</p>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {recommendations.recommendedBookIds?.map((bookId: number) => {
                  const book = books.find((b) => b.id === bookId);
                  return book ? (
                    <Card key={bookId} className="card-cinematic p-4">
                      <h3 className="font-semibold text-foreground truncate-2">{book.title}</h3>
                      <p className="text-sm text-muted-foreground truncate">{book.author}</p>
                      <Button
                        onClick={() => handleReserveBook(book.id)}
                        className="w-full btn-cinematic text-sm mt-4"
                        disabled={book.availableCopies === 0}
                      >
                        {book.availableCopies > 0 ? "Reserve" : "Reserve (Waitlist)"}
                      </Button>
                    </Card>
                  ) : null;
                })}
              </div>
            </div>
          )}
        </TabsContent>

        {/* Account Tab */}
        <TabsContent value="account" className="space-y-4 mt-6">
          <Card className="card-cinematic p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Member Information</h3>
            <div className="space-y-3">
              <div>
                <p className="text-sm text-muted-foreground">Name</p>
                <p className="font-medium text-foreground">{user?.name}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Email</p>
                <p className="font-medium text-foreground">{user?.email}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Membership Number</p>
                <p className="font-medium text-foreground">{memberProfile?.membershipNumber || "N/A"}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Status</p>
                <p className="font-medium text-foreground capitalize">{memberProfile?.status || "N/A"}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Books Issued</p>
                <p className="font-medium text-foreground">{memberProfile?.totalBooksIssued || 0}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Fines Paid</p>
                <p className="font-medium text-foreground">${parseFloat(memberProfile?.totalFinesPaid?.toString() || "0").toFixed(2)}</p>
              </div>
            </div>
          </Card>

          {memberFines.length > 0 && (
            <Card className="card-cinematic p-6 border-l-4 border-l-secondary">
              <h3 className="text-lg font-semibold text-secondary mb-4">Pending Fines</h3>
              <div className="space-y-2">
                {memberFines.map((fine: any) => (
                  <div key={fine.id} className="flex justify-between items-center pb-2 border-b border-border last:border-0">
                    <div>
                      <p className="font-medium text-foreground">{fine.reason}</p>
                      <p className="text-sm text-muted-foreground">Transaction #{fine.transactionId}</p>
                    </div>
                    <span className="badge-cinematic-orange">${parseFloat(fine.amount?.toString() || "0").toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
