import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Search, Edit2, Trash2, Users, BookOpen, TrendingUp } from "lucide-react";
import { toast } from "sonner";

export default function LibrarianDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch analytics data
  const { data: overdueStats } = trpc.analytics.overdueStats.useQuery();
  const { data: borrowingTrends } = trpc.analytics.borrowingTrends.useQuery({ days: 30 });
  const { data: popularBooks } = trpc.analytics.mostPopularBooks.useQuery({ limit: 5 });

  // Fetch books and members
  const { data: books = [], isLoading: booksLoading } = trpc.books.list.useQuery({ limit: 100 });
  const { data: members = [], isLoading: membersLoading } = trpc.members.list.useQuery({ limit: 100 });
  const { data: overdueTransactions = [] } = trpc.transactions.getOverdue.useQuery();

  // Mutations
  const deleteBookMutation = trpc.books.delete.useMutation({
    onSuccess: () => {
      toast.success("Book deleted successfully");
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete book");
    },
  });

  const handleDeleteBook = (id: number) => {
    if (confirm("Are you sure you want to delete this book?")) {
      deleteBookMutation.mutate({ id });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="card-cinematic p-8">
        <h1 className="heading-cinematic text-3xl md:text-4xl">Librarian Dashboard</h1>
        <p className="subheading-cinematic mt-2">Manage your library operations</p>
      </div>

      {/* Stats Overview */}
      <div className="grid-cinematic">
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="stat-label">Total Books</p>
              <p className="stat-value">{books.length}</p>
            </div>
            <BookOpen className="w-12 h-12 text-primary opacity-50" />
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="stat-label">Active Members</p>
              <p className="stat-value">{members.length}</p>
            </div>
            <Users className="w-12 h-12 text-primary opacity-50" />
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="stat-label">Overdue Books</p>
              <p className="stat-value">{(overdueStats as any)?.overdueCount || 0}</p>
            </div>
            <TrendingUp className="w-12 h-12 text-secondary opacity-50" />
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="stat-label">Pending Fines</p>
              <p className="stat-value">${((overdueStats as any)?.totalPendingFines || 0).toFixed(2)}</p>
            </div>
            <TrendingUp className="w-12 h-12 text-secondary opacity-50" />
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="card-cinematic p-6">
        <TabsList className="grid w-full grid-cols-4 bg-card/50">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="books">Books</TabsTrigger>
          <TabsTrigger value="members">Members</TabsTrigger>
          <TabsTrigger value="overdue">Overdue</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Popular Books */}
            <Card className="card-cinematic p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Most Popular Books</h3>
              <div className="space-y-3">
                {popularBooks?.map((item: any, idx) => (
                  <div key={idx} className="flex justify-between items-center pb-3 border-b border-border last:border-0">
                    <div>
                      <p className="font-medium text-foreground">{item.book?.title}</p>
                      <p className="text-sm text-muted-foreground">{item.book?.author}</p>
                    </div>
                    <span className="badge-cinematic">{item.borrowCount} borrows</span>
                  </div>
                ))}
              </div>
            </Card>

            {/* Borrowing Trends */}
            <Card className="card-cinematic p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Borrowing Trends (Last 30 Days)</h3>
              <div className="space-y-2">
                {borrowingTrends?.slice(-7).map((item: any, idx) => (
                  <div key={idx} className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">{item.date}</span>
                    <div className="flex items-center gap-2">
                      <div className="h-2 bg-primary/30 rounded" style={{ width: `${(item.count * 20)}px` }}></div>
                      <span className="text-sm font-medium text-primary">{item.count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </TabsContent>

        {/* Books Tab */}
        <TabsContent value="books" className="space-y-4 mt-6">
          <div className="flex gap-2 mb-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search books..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="input-cinematic pl-10"
              />
            </div>
            <Button className="btn-cinematic gap-2">
              <Plus className="w-4 h-4" />
              Add Book
            </Button>
          </div>

          <div className="overflow-x-auto">
            <table className="table-cinematic">
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Author</th>
                  <th>ISBN</th>
                  <th>Available</th>
                  <th>Total</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {booksLoading ? (
                  <tr>
                    <td colSpan={6} className="text-center py-4">Loading...</td>
                  </tr>
                ) : books.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-4 text-muted-foreground">No books found</td>
                  </tr>
                ) : (
                  books.map((book) => (
                    <tr key={book.id}>
                      <td className="font-medium">{book.title}</td>
                      <td>{book.author}</td>
                      <td className="text-sm text-muted-foreground">{book.isbn || "-"}</td>
                      <td>
                        <span className="badge-cinematic">{book.availableCopies}</span>
                      </td>
                      <td>{book.totalCopies}</td>
                      <td>
                        <div className="flex gap-2">
                          <button className="p-1 hover:bg-primary/10 rounded transition-colors">
                            <Edit2 className="w-4 h-4 text-primary" />
                          </button>
                          <button
                            onClick={() => handleDeleteBook(book.id)}
                            className="p-1 hover:bg-destructive/10 rounded transition-colors"
                          >
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </TabsContent>

        {/* Members Tab */}
        <TabsContent value="members" className="space-y-4 mt-6">
          <div className="flex gap-2 mb-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search members..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="input-cinematic pl-10"
              />
            </div>
            <Button className="btn-cinematic gap-2">
              <Plus className="w-4 h-4" />
              Register Member
            </Button>
          </div>

          <div className="overflow-x-auto">
            <table className="table-cinematic">
              <thead>
                <tr>
                  <th>Member Number</th>
                  <th>Status</th>
                  <th>Books Issued</th>
                  <th>Fines Paid</th>
                  <th>Join Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {membersLoading ? (
                  <tr>
                    <td colSpan={6} className="text-center py-4">Loading...</td>
                  </tr>
                ) : members.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-4 text-muted-foreground">No members found</td>
                  </tr>
                ) : (
                  members.map((member: any) => (
                    <tr key={member.id}>
                      <td className="font-medium">{member.membershipNumber}</td>
                      <td>
                        <span className={`badge-cinematic ${member.status === "active" ? "" : "opacity-50"}`}>
                          {member.status}
                        </span>
                      </td>
                      <td>{member.totalBooksIssued}</td>
                      <td>${parseFloat(member.totalFinesPaid || "0").toFixed(2)}</td>
                      <td className="text-sm text-muted-foreground">
                        {new Date(member.joinDate).toLocaleDateString()}
                      </td>
                      <td>
                        <div className="flex gap-2">
                          <button className="p-1 hover:bg-primary/10 rounded transition-colors">
                            <Edit2 className="w-4 h-4 text-primary" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </TabsContent>

        {/* Overdue Tab */}
        <TabsContent value="overdue" className="space-y-4 mt-6">
          <div className="overflow-x-auto">
            <table className="table-cinematic">
              <thead>
                <tr>
                  <th>Book</th>
                  <th>Member</th>
                  <th>Due Date</th>
                  <th>Days Overdue</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {overdueTransactions.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="text-center py-4 text-muted-foreground">No overdue books</td>
                  </tr>
                ) : (
                  overdueTransactions.map((transaction: any) => {
                    const daysOverdue = Math.ceil(
                      (new Date().getTime() - new Date(transaction.dueDate).getTime()) / (1000 * 60 * 60 * 24)
                    );
                    return (
                      <tr key={transaction.id}>
                        <td className="font-medium">Book #{transaction.bookId}</td>
                        <td>Member #{transaction.memberId}</td>
                        <td className="text-sm text-muted-foreground">
                          {new Date(transaction.dueDate).toLocaleDateString()}
                        </td>
                        <td>
                          <span className="badge-cinematic-orange">{daysOverdue} days</span>
                        </td>
                        <td>
                          <Button className="btn-cinematic text-xs py-1 px-3">Send Reminder</Button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
